import { Component, OnInit } from '@angular/core';
import { MedicosService } from './medicos/medicos.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PagHospital';
  medicos:any;

  constructor(public medico:MedicosService){}

  ngOnInit(){
    this.medico.getMedicos().subscribe(
      (r)=> {this.medicos = r ; console.log(r)}
    )
  }
}
