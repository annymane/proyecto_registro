export class Medicos{
    public nombres:String='';
    public apellidos:String='';
}