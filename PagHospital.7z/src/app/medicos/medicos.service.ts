import { Injectable } from "@angular/core";
import { Observable, observable } from "rxjs";
import { HttpClient } from "@angular/common/http";

@Injectable()

export class MedicosService{
    private Api = "http://localhost:8080/medicos"

    constructor(public http:HttpClient){}

    public getMedicos():Observable<any>{
        return this.http.get(this.Api);
    }
}