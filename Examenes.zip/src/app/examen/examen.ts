export class Examen
{
    public ID_examen:string = '';
    public Descripcion:string = '';
    public Nombre:string = '';
}